"""
Traffic Flow Simulation — Multi-Lane Nagel-Schreckenberg (NaSch) Model
=======================================================================
Version : 4.0.0  (Traffic Light Extension)

Extends v3.0 (multi-lane NaSch + error analysis) with traffic lights
placed at fixed positions on the road.  Each light cycles through RED
→ GREEN states with configurable cycle lengths.

Traffic-light rules (applied BEFORE the NaSch speed update)
------------------------------------------------------------
  • A car whose gap-to-next-car would carry it through or onto a RED
    light cell is forced to stop at the cell just before the light.
  • When the light is GREEN the constraint is removed and cars flow
    normally under the standard NaSch rules.
  • Multiple lights can be placed at arbitrary positions.

Lane-changing rules (applied before the NaSch speed update)
-----------------------------------------------------------
  Same MOBIL-inspired rules as v3.0.

New UI slider
-------------
  • TL Cycle  (5–60 steps) — shared red+green half-period for all lights.

New visualisation
-----------------
  • Traffic-light markers drawn as RED or GREEN vertical lines on the
    road strip, updated every animation frame.
  • Space-time diagram shows lights as vertical dashed lines so jam
    propagation from lights is visible.
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.gridspec as gridspec
from matplotlib.widgets import Slider, Button
import warnings
warnings.filterwarnings("ignore")


# ─────────────────────────────────────────────────────────────────────────────
# Colour palette
# ─────────────────────────────────────────────────────────────────────────────

ROAD_COLOR   = "#1a1a2e"
BG_COLOR     = "#0a0a1a"
TEXT_COLOR   = "#e0e0f0"
ACCENT_COLOR = "#4ecca3"
GRID_COLOR   = "#2a2a4a"

LANE_COLORS      = ["#4ecca3", "#f7b731", "#e94560", "#a29bfe"]
LANE_BAND_COLORS = ["#1e1e3a", "#1e2a1e", "#2a1e1e", "#1e1e2a"]

TL_RED_COLOR   = "#ff3333"
TL_GREEN_COLOR = "#33ff77"


def speed_color(v, v_max):
    """Map speed → RGB on a red→yellow→green gradient."""
    t = v / max(v_max, 1)
    r = int(255 * (1 - t))
    g = int(200 * t + 55)
    b = 80
    return (r / 255, g / 255, b / 255)


# ─────────────────────────────────────────────────────────────────────────────
# Traffic Light
# ─────────────────────────────────────────────────────────────────────────────

class TrafficLight:
    """
    A traffic light at a fixed cell position.

    Parameters
    ----------
    position   : int   Cell index of the stop line.
    cycle      : int   Number of steps for each RED and each GREEN phase.
    phase_offset: int  Initial phase offset (steps), allows staggering lights.
    """

    def __init__(self, position, cycle=20, phase_offset=0):
        self.position     = position
        self.cycle        = cycle
        self._step        = phase_offset % (2 * cycle)

    def advance(self):
        """Advance the light by one step."""
        self._step = (self._step + 1) % (2 * self.cycle)

    def is_red(self):
        """True when the light is RED."""
        return self._step < self.cycle

    def is_green(self):
        return not self.is_red()

    def set_cycle(self, new_cycle):
        """Update cycle length, preserving relative phase."""
        self._step = int(self._step * new_cycle / max(self.cycle, 1)) % (2 * new_cycle)
        self.cycle = new_cycle


# ─────────────────────────────────────────────────────────────────────────────
# Multi-lane NaSch model  (with traffic light support)
# ─────────────────────────────────────────────────────────────────────────────

class MultiLaneNaSch:
    """
    Multi-lane circular-road NaSch model with lane-changing and traffic lights.

    Parameters
    ----------
    road_length  : int    Number of cells per lane.
    num_cars     : int    Total cars distributed evenly across lanes.
    num_lanes    : int    Number of parallel lanes (1–4).
    v_max        : int    Speed ceiling (cells/step).
    p_brake      : float  Spontaneous-braking probability.
    p_change     : float  Politeness threshold for lane changes (0–1).
    seed         : int    RNG seed.
    traffic_lights: list  List of TrafficLight objects (may be empty).
    """

    def __init__(self, road_length=100, num_cars=30, num_lanes=2,
                 v_max=5, p_brake=0.3, p_change=0.3, seed=42,
                 traffic_lights=None):
        self.L             = road_length
        self.n_lanes       = num_lanes
        self.v_max         = v_max
        self.p_brake       = p_brake
        self.p_change      = p_change
        self.rng           = np.random.default_rng(seed)
        self.traffic_lights = traffic_lights if traffic_lights is not None else []
        self.reset(num_cars)

    # ── Initialisation ────────────────────────────────────────────────────────

    def reset(self, num_cars=None):
        if num_cars is not None:
            self.N = num_cars

        self.positions  = []
        self.velocities = []

        cars_per_lane = max(1, self.N // self.n_lanes)

        for lane in range(self.n_lanes):
            n = cars_per_lane if lane < self.n_lanes - 1 else max(1, self.N - cars_per_lane * (self.n_lanes - 1))
            pos = np.sort(self.rng.choice(self.L, size=min(n, self.L), replace=False)).astype(float)
            vel = self.rng.integers(0, self.v_max + 1, size=len(pos)).astype(float)
            self.positions.append(pos)
            self.velocities.append(vel)

        self.step_count = 0

    # ── Gap computation ───────────────────────────────────────────────────────

    def _gap_ahead(self, pos_lane, pos_i):
        if len(pos_lane) == 0:
            return self.L - 1
        ahead = (pos_lane - pos_i) % self.L
        ahead[ahead == 0] = self.L
        return np.min(ahead) - 1

    def _gap_behind(self, pos_lane, pos_i):
        if len(pos_lane) == 0:
            return self.L - 1
        behind = (pos_i - pos_lane) % self.L
        behind[behind == 0] = self.L
        return np.min(behind) - 1

    # ── Lane changing ─────────────────────────────────────────────────────────

    def _lane_change_step(self):
        if self.n_lanes < 2:
            return

        new_pos = [p.copy() for p in self.positions]
        new_vel = [v.copy() for v in self.velocities]

        for lane in range(self.n_lanes):
            n_cars = len(self.positions[lane])
            order  = self.rng.permutation(n_cars)

            for idx in order:
                pos_i = self.positions[lane][idx]
                vel_i = self.velocities[lane][idx]
                gap_cur = self._gap_ahead(self.positions[lane], pos_i)

                candidates = []
                if lane > 0:
                    candidates.append(lane - 1)
                if lane < self.n_lanes - 1:
                    candidates.append(lane + 1)

                for target in candidates:
                    gap_tgt = self._gap_ahead(new_pos[target], pos_i)
                    gap_bk  = self._gap_behind(new_pos[target], pos_i)

                    incentive = gap_tgt > gap_cur
                    safe      = gap_bk >= max(self.v_max - 1, 1)
                    polite    = gap_bk >= self.p_change * self.v_max

                    if incentive and safe and polite:
                        new_pos[target] = np.append(new_pos[target], pos_i)
                        new_vel[target] = np.append(new_vel[target], vel_i)
                        mask = new_pos[lane] != pos_i
                        new_pos[lane] = new_pos[lane][mask]
                        new_vel[lane] = new_vel[lane][mask]
                        break

        for lane in range(self.n_lanes):
            order = np.argsort(new_pos[lane])
            self.positions[lane]  = new_pos[lane][order]
            self.velocities[lane] = new_vel[lane][order]

    # ── Traffic-light constraint ──────────────────────────────────────────────

    def _apply_traffic_lights(self, pos, vel):
        """
        For each RED light, cap the speed of any car that would cross
        the stop line this step.  The car is forced to stop just before
        the light (distance-1 from the stop cell).
        """
        if not self.traffic_lights:
            return vel

        vel = vel.copy()
        for tl in self.traffic_lights:
            if tl.is_green():
                continue
            stop_cell = float(tl.position)
            for i, (p, v) in enumerate(zip(pos, vel)):
                # distance from car to stop line (periodic)
                dist = (stop_cell - p) % self.L
                if 0 < dist <= v:
                    # car would reach or cross the red light → stop before it
                    vel[i] = max(dist - 1, 0)
        return vel

    # ── NaSch time step ───────────────────────────────────────────────────────

    def _nasch_step_lane(self, pos, vel):
        """Apply the four NaSch rules to a single lane, respecting lights."""
        N = len(pos)
        if N == 0:
            return pos, vel

        L, v_max = self.L, self.v_max

        next_pos = np.roll(pos, -1)
        next_pos_wrapped = np.where(next_pos <= pos, next_pos + L, next_pos)
        gaps = next_pos_wrapped - pos - 1

        vel = np.minimum(vel + 1, v_max)                               # Rule 1
        vel = np.minimum(vel, gaps)                                     # Rule 2
        vel = self._apply_traffic_lights(pos, vel)                      # TL constraint
        brake_mask = self.rng.random(N) < self.p_brake
        vel = np.maximum(vel - brake_mask.astype(float), 0)            # Rule 3
        pos = (pos + vel) % L                                          # Rule 4

        return pos, vel

    def step(self):
        """Advance one time step: advance lights, lane changes, NaSch."""
        for tl in self.traffic_lights:
            tl.advance()
        self._lane_change_step()
        for lane in range(self.n_lanes):
            p, v = self._nasch_step_lane(self.positions[lane], self.velocities[lane])
            self.positions[lane]  = p
            self.velocities[lane] = v
        self.step_count += 1
        return self.positions, self.velocities

    # ── Aggregates ────────────────────────────────────────────────────────────

    def total_cars(self):
        return sum(len(p) for p in self.positions)

    def lane_density(self, lane):
        return len(self.positions[lane]) / self.L

    def lane_avg_speed(self, lane):
        v = self.velocities[lane]
        return float(np.mean(v)) if len(v) > 0 else 0.0

    def lane_flow(self, lane):
        return self.lane_avg_speed(lane) * self.lane_density(lane)

    def overall_density(self):
        return self.total_cars() / (self.L * self.n_lanes)

    def overall_flow(self):
        return np.mean([self.lane_flow(l) for l in range(self.n_lanes)])

    def overall_avg_speed(self):
        all_v = np.concatenate(self.velocities) if any(len(v) > 0 for v in self.velocities) else np.array([0.0])
        return float(np.mean(all_v))

    def all_velocities(self):
        if any(len(v) > 0 for v in self.velocities):
            return np.concatenate(self.velocities)
        return np.array([0.0])


# ─────────────────────────────────────────────────────────────────────────────
# Fundamental diagram helper
# ─────────────────────────────────────────────────────────────────────────────

def compute_fundamental_diagram(road_length=100, v_max=5, p_brake=0.3,
                                num_lanes=2, densities=None,
                                warmup=200, measure=100,
                                traffic_lights=None):
    if densities is None:
        densities = np.linspace(0.01, 0.99, 40)

    flows, speeds = [], []
    for rho in densities:
        n = max(1, int(rho * road_length * num_lanes))
        model = MultiLaneNaSch(road_length, n, num_lanes, v_max, p_brake,
                               traffic_lights=traffic_lights)
        for _ in range(warmup):
            model.step()
        fv, sv = [], []
        for _ in range(measure):
            model.step()
            fv.append(model.overall_flow())
            sv.append(model.overall_avg_speed())
        flows.append(np.mean(fv))
        speeds.append(np.mean(sv))
    return np.array(densities), np.array(flows), np.array(speeds)


# ─────────────────────────────────────────────────────────────────────────────
# ERROR ANALYSIS & BOUNDARY CASES
# ─────────────────────────────────────────────────────────────────────────────

def run_error_analysis():
    print("\n=== Running Error Analysis — this may take ~30 seconds ===\n")

    fig = plt.figure(figsize=(16, 11), facecolor=BG_COLOR)
    fig.suptitle(
        "NaSch Traffic Model — Error Analysis & Boundary Cases",
        color=ACCENT_COLOR, fontsize=13, fontweight="bold", y=0.98)

    gs = gridspec.GridSpec(2, 2, figure=fig,
                           hspace=0.45, wspace=0.38,
                           top=0.93, bottom=0.07,
                           left=0.08, right=0.96)

    ax1 = fig.add_subplot(gs[0, 0])
    ax2 = fig.add_subplot(gs[0, 1])
    ax3 = fig.add_subplot(gs[1, 0])
    ax4 = fig.add_subplot(gs[1, 1])

    for ax in [ax1, ax2, ax3, ax4]:
        ax.set_facecolor(ROAD_COLOR)
        for sp in ax.spines.values():
            sp.set_color(GRID_COLOR)
        ax.tick_params(colors=TEXT_COLOR, labelsize=7)
        ax.xaxis.label.set_color(TEXT_COLOR)
        ax.yaxis.label.set_color(TEXT_COLOR)
        ax.title.set_color(ACCENT_COLOR)

    # Panel 1: Finite-size error
    road_lengths = [25, 50, 100, 200, 400]
    flow_stds    = []
    rho_test     = 0.25
    v_max_test   = 5
    p_brake_test = 0.3
    n_lanes_test = 2
    measure_steps = 200

    print("  Panel 1: Finite-size error sweep...")
    for L in road_lengths:
        n_cars = max(2, int(rho_test * L * n_lanes_test))
        model  = MultiLaneNaSch(L, n_cars, n_lanes_test, v_max_test, p_brake_test, seed=0)
        for _ in range(max(200, L * 2)):
            model.step()
        samples = []
        for _ in range(measure_steps):
            model.step()
            samples.append(model.overall_flow())
        flow_stds.append(np.std(samples))

    road_lengths_arr = np.array(road_lengths, dtype=float)
    flow_stds_arr    = np.array(flow_stds)
    ref_scale = flow_stds_arr[0] * road_lengths_arr[0]
    ref_line  = ref_scale / road_lengths_arr

    ax1.plot(road_lengths_arr, flow_stds_arr,
             "o-", color=ACCENT_COLOR, lw=1.8, ms=6, label="Measured std(Q)")
    ax1.plot(road_lengths_arr, ref_line,
             "--", color="#f7b731", lw=1.2, label="O(1/L) reference")
    ax1.set_xscale("log"); ax1.set_yscale("log")
    ax1.set_title("Panel 1 — Finite-Size (Numerical) Error\nstd(Q) vs Road Length L  [log–log]", fontsize=8)
    ax1.set_xlabel("Road Length L (cells)", fontsize=7)
    ax1.set_ylabel("std of steady-state Flow Q", fontsize=7)
    ax1.legend(fontsize=6, facecolor=ROAD_COLOR, labelcolor=TEXT_COLOR, framealpha=0.7)
    ax1.grid(True, color=GRID_COLOR, lw=0.4, which="both", alpha=0.5)

    # Panel 2: Warmup convergence
    print("  Panel 2: Warmup convergence curves...")
    convergence_densities = [0.10, 0.25, 0.60]
    convergence_colors    = [LANE_COLORS[0], LANE_COLORS[1], LANE_COLORS[2]]
    total_steps = 500; L_conv = 100

    for rho, col in zip(convergence_densities, convergence_colors):
        n_cars = max(1, int(rho * L_conv * 2))
        model  = MultiLaneNaSch(L_conv, n_cars, 2, v_max_test, p_brake_test, seed=7)
        running_flows = []; cum = 0.0
        for t in range(total_steps):
            model.step()
            cum += model.overall_flow()
            running_flows.append(cum / (t + 1))
        ax2.plot(range(total_steps), running_flows, color=col, lw=1.4, label=f"ρ = {rho:.2f}")

    ax2.axvspan(0, 300, alpha=0.10, color="#e94560", label="Warmup region (300 steps)")
    ax2.axvline(300, color="#e94560", lw=1.0, ls="--")
    ax2.set_title("Panel 2 — Warmup Convergence\nRunning mean of Flow Q vs Time Step", fontsize=8)
    ax2.set_xlabel("Time step", fontsize=7)
    ax2.set_ylabel("Running mean of Flow Q", fontsize=7)
    ax2.legend(fontsize=6, facecolor=ROAD_COLOR, labelcolor=TEXT_COLOR, framealpha=0.7)
    ax2.grid(True, color=GRID_COLOR, lw=0.4, alpha=0.5)

    # Panel 3: Boundary cases
    print("  Panel 3: Boundary case snapshots...")
    ax3.axis("off")
    ax3.set_title("Panel 3 — Boundary Cases\n(space-time: bright=fast, dark=slow)", fontsize=8)

    boundary_cases = [
        ("(a) ρ → 0\nFree flow",       0.03,  0.30),
        ("(b) ρ → 1\nGridlock",        0.97,  0.30),
        ("(c) p_brake=0\nDeterministic",0.25, 0.00),
        ("(d) p_brake=1\nMax disorder", 0.25,  1.00),
    ]

    bbox = ax3.get_position()
    x0, y0, w, h = bbox.x0, bbox.y0, bbox.width, bbox.height
    pad = 0.01; sub_w = w / 2 - pad; sub_h = h / 2 - pad * 2.5
    sub_positions = [
        [x0,               y0 + sub_h + pad * 3, sub_w, sub_h],
        [x0 + sub_w + pad, y0 + sub_h + pad * 3, sub_w, sub_h],
        [x0,               y0,                   sub_w, sub_h],
        [x0 + sub_w + pad, y0,                   sub_w, sub_h],
    ]

    snap_L = 80; snap_steps = 80
    for i, (label, rho, p_brake) in enumerate(boundary_cases):
        n_cars = max(1, int(rho * snap_L))
        model  = MultiLaneNaSch(snap_L, n_cars, 1, v_max=5, p_brake=p_brake, seed=99)
        for _ in range(150): model.step()
        grid = np.zeros((snap_steps, snap_L))
        for t in range(snap_steps):
            model.step()
            if len(model.positions[0]) > 0:
                idxs = model.positions[0].astype(int) % snap_L
                grid[t, idxs] = model.velocities[0] / 5.0
        sub_ax = fig.add_axes(sub_positions[i])
        sub_ax.imshow(grid, aspect="auto", origin="upper", cmap="hot", vmin=0, vmax=1,
                      extent=[0, snap_L, snap_steps, 0])
        sub_ax.set_title(label, color=ACCENT_COLOR, fontsize=6.5, pad=2)
        sub_ax.set_xticks([]); sub_ax.set_yticks([])
        for sp in sub_ax.spines.values():
            sp.set_color(LANE_COLORS[i % len(LANE_COLORS)]); sp.set_linewidth(1.2)

    # Panel 4: Phase diagram
    print("  Panel 4: Phase diagram heatmap...")
    n_pts = 20
    rho_vals  = np.linspace(0.02, 0.98, n_pts)
    pb_vals   = np.linspace(0.00, 1.00, n_pts)
    flow_grid = np.zeros((n_pts, n_pts))

    for i, rho in enumerate(rho_vals):
        for j, pb in enumerate(pb_vals):
            n_cars = max(1, int(rho * 100))
            model  = MultiLaneNaSch(100, n_cars, 1, v_max=5, p_brake=pb, seed=0)
            for _ in range(200): model.step()
            fv = [model.overall_flow() for _ in range(100) if model.step() is not None or True]
            flow_grid[j, i] = np.mean(fv)

    im = ax4.imshow(flow_grid, aspect="auto", origin="lower", cmap="plasma",
                    extent=[rho_vals[0], rho_vals[-1], pb_vals[0], pb_vals[-1]])
    cbar = fig.colorbar(im, ax=ax4, fraction=0.046, pad=0.04)
    cbar.set_label("Steady-state Flow Q", color=TEXT_COLOR, fontsize=7)
    cbar.ax.yaxis.set_tick_params(color=TEXT_COLOR, labelsize=6)
    plt.setp(cbar.ax.yaxis.get_ticklabels(), color=TEXT_COLOR)
    ax4.set_title("Panel 4 — Phase Diagram\nFlow Q over (Density ρ × Brake Prob p)", fontsize=8)
    ax4.set_xlabel("Density ρ", fontsize=7); ax4.set_ylabel("Brake Probability p", fontsize=7)
    rho_c = 1.0 / 6.0
    ax4.axvline(rho_c, color="#4ecca3", lw=1.2, ls="--", label=f"ρ_c ≈ {rho_c:.2f}")
    ax4.legend(fontsize=6, facecolor=ROAD_COLOR, labelcolor=TEXT_COLOR, framealpha=0.8, loc="upper right")
    ax4.text(rho_c * 0.45, 0.85, "Free\nFlow", color="white", fontsize=7, ha="center",
             bbox=dict(boxstyle="round,pad=0.2", facecolor="#00000088"))
    ax4.text(rho_c * 2.8, 0.85, "Congested\nPhase", color="white", fontsize=7, ha="center",
             bbox=dict(boxstyle="round,pad=0.2", facecolor="#00000088"))

    print("\n=== Error Analysis complete ===\n")
    plt.show()


# ─────────────────────────────────────────────────────────────────────────────
# Main UI  (v4.0 — adds traffic lights)
# ─────────────────────────────────────────────────────────────────────────────

class TrafficSimUI:
    """
    Interactive multi-lane traffic simulation with traffic lights.

    Layout
    ------
    Row 0  : Road strip with traffic light markers.
    Row 1  : Space-time diagram with light positions shown.
    Row 2  : Fundamental diagram | Speed histogram | Live stats.
    Bottom : Sliders (Density, Max Speed, Brake Prob, Num Lanes, TL Cycle) + Buttons.
    """

    # Default traffic light positions (2 lights on a 100-cell road)
    TL_POSITIONS = [25, 75]

    def __init__(self):
        self.road_length   = 100
        self.density_init  = 0.30
        self.v_max_init    = 5
        self.p_brake_init  = 0.30
        self.n_lanes_init  = 2
        self.tl_cycle_init = 20

        self.n_lanes  = self.n_lanes_init
        self.n_cars   = int(self.density_init * self.road_length * self.n_lanes)

        self._make_lights(self.tl_cycle_init)

        self.model = MultiLaneNaSch(
            self.road_length, self.n_cars, self.n_lanes,
            self.v_max_init, self.p_brake_init,
            traffic_lights=self.lights)

        self.running     = True
        self.history_len = 150
        self._init_spacetime_buffer()
        self._warmup()
        self._build_figure()

    def _make_lights(self, cycle):
        """Create two traffic lights at fixed positions with staggered phases."""
        self.lights = [
            TrafficLight(pos, cycle=cycle, phase_offset=i * cycle)
            for i, pos in enumerate(self.TL_POSITIONS)
        ]

    def _init_spacetime_buffer(self):
        rows_per_lane       = self.history_len // max(self.n_lanes, 1)
        self._rows_per_lane = rows_per_lane
        self.spacetime      = np.zeros((rows_per_lane * self.n_lanes, self.road_length))

    def _warmup(self, steps=300):
        for _ in range(steps):
            pos_list, vel_list = self.model.step()
            self._push_spacetime(pos_list, vel_list)

    def _push_spacetime(self, pos_list, vel_list):
        rpl = self._rows_per_lane
        for lane in range(self.n_lanes):
            row = np.zeros(self.road_length)
            if len(pos_list[lane]) > 0:
                idxs = pos_list[lane].astype(int) % self.road_length
                row[idxs] = vel_list[lane] / max(self.model.v_max, 1)
            start = lane * rpl
            self.spacetime[start:start + rpl] = np.roll(
                self.spacetime[start:start + rpl], -1, axis=0)
            self.spacetime[start + rpl - 1] = row

    # ── Figure construction ───────────────────────────────────────────────────

    def _build_figure(self):
        plt.close("all")

        self.fig = plt.figure(figsize=(16, 9), facecolor=BG_COLOR)
        try:
            self.fig.canvas.manager.set_window_title(
                "Multi-Lane Traffic Simulation — NaSch Model v4 (Traffic Lights)")
        except Exception:
            pass

        gs = gridspec.GridSpec(
            3, 3, figure=self.fig,
            hspace=0.55, wspace=0.40,
            top=0.92, bottom=0.22, left=0.06, right=0.97)

        self.ax_road  = self.fig.add_subplot(gs[0, :])
        self.ax_space = self.fig.add_subplot(gs[1, :])
        self.ax_flow  = self.fig.add_subplot(gs[2, 0])
        self.ax_speed = self.fig.add_subplot(gs[2, 1])
        self.ax_stats = self.fig.add_subplot(gs[2, 2])

        for ax in [self.ax_road, self.ax_space, self.ax_flow,
                   self.ax_speed, self.ax_stats]:
            ax.set_facecolor(ROAD_COLOR)
            for sp in ax.spines.values():
                sp.set_color(GRID_COLOR)
            ax.tick_params(colors=TEXT_COLOR, labelsize=7)
            ax.xaxis.label.set_color(TEXT_COLOR)
            ax.yaxis.label.set_color(TEXT_COLOR)
            ax.title.set_color(ACCENT_COLOR)

        slider_kw    = dict(facecolor="#1e1e3a")
        slider_style = dict(color=ACCENT_COLOR, track_color="#2a2a4a")

        axs_den   = self.fig.add_axes([0.06, 0.17, 0.17, 0.020], **slider_kw)
        axs_vmax  = self.fig.add_axes([0.06, 0.13, 0.17, 0.020], **slider_kw)
        axs_brake = self.fig.add_axes([0.06, 0.09, 0.17, 0.020], **slider_kw)
        axs_lanes = self.fig.add_axes([0.06, 0.05, 0.17, 0.020], **slider_kw)
        axs_tlcyc = self.fig.add_axes([0.06, 0.01, 0.17, 0.020], **slider_kw)

        self.sl_den   = Slider(axs_den,   "Density",    0.05, 0.95, valinit=self.density_init,  valstep=0.01, **slider_style)
        self.sl_vmax  = Slider(axs_vmax,  "Max Speed",  1,    10,   valinit=self.v_max_init,    valstep=1,    **slider_style)
        self.sl_brake = Slider(axs_brake, "Brake Prob", 0.0,  1.0,  valinit=self.p_brake_init,  valstep=0.01, **slider_style)
        self.sl_lanes = Slider(axs_lanes, "Num Lanes",  1,    4,    valinit=self.n_lanes_init,  valstep=1,    **slider_style)
        self.sl_tlcyc = Slider(axs_tlcyc, "TL Cycle",  5,    60,   valinit=self.tl_cycle_init, valstep=1,    **slider_style)

        for sl in [self.sl_den, self.sl_vmax, self.sl_brake, self.sl_lanes, self.sl_tlcyc]:
            sl.label.set_color(TEXT_COLOR)
            sl.valtext.set_color(ACCENT_COLOR)

        self.sl_den.on_changed(self._on_param_change)
        self.sl_vmax.on_changed(self._on_param_change)
        self.sl_brake.on_changed(self._on_param_change)
        self.sl_lanes.on_changed(self._on_lane_change)
        self.sl_tlcyc.on_changed(self._on_tl_cycle_change)

        btn_kw = dict(color="#16213e", hovercolor="#0f3460")
        ax_bp  = self.fig.add_axes([0.30, 0.10, 0.08, 0.05])
        ax_br  = self.fig.add_axes([0.40, 0.10, 0.08, 0.05])
        ax_bf  = self.fig.add_axes([0.50, 0.10, 0.16, 0.05])

        self.btn_pause = Button(ax_bp, "⏸ Pause",              **btn_kw)
        self.btn_reset = Button(ax_br, "↺ Reset",              **btn_kw)
        self.btn_fund  = Button(ax_bf, "📊 Recompute Diagram", **btn_kw)

        for btn in [self.btn_pause, self.btn_reset, self.btn_fund]:
            btn.label.set_color(TEXT_COLOR)

        self.btn_pause.on_clicked(self._toggle_pause)
        self.btn_reset.on_clicked(self._reset)
        self.btn_fund.on_clicked(self._recompute_fund)

        self.fig.text(
            0.5, 0.965,
            "Multi-Lane Traffic Flow Simulation — NaSch Model v4.0  (Traffic Lights)",
            ha="center", va="top",
            color=ACCENT_COLOR, fontsize=12, fontweight="bold")

        self._init_road_plot()
        self._init_spacetime_plot()
        self._init_fund_diagram()
        self._init_speed_hist()
        self._init_stats()

        self.anim = animation.FuncAnimation(
            self.fig, self._update,
            interval=120, blit=False, cache_frame_data=False)

        plt.show()

    # ── Road plot ─────────────────────────────────────────────────────────────

    def _init_road_plot(self):
        ax = self.ax_road
        ax.cla()
        ax.set_facecolor(ROAD_COLOR)
        for sp in ax.spines.values():
            sp.set_color(GRID_COLOR)

        L, nl = self.road_length, self.n_lanes

        ax.set_xlim(-0.5, L - 0.5)
        ax.set_ylim(-0.6, nl - 0.4)
        ax.set_yticks(range(nl))
        ax.set_yticklabels([f"Lane {l+1}" for l in range(nl)], color=TEXT_COLOR, fontsize=7)
        ax.tick_params(colors=TEXT_COLOR, labelsize=7)
        ax.set_xlabel("Cell", fontsize=7)
        ax.xaxis.label.set_color(TEXT_COLOR)
        ax.title.set_color(ACCENT_COLOR)
        ax.set_title(f"Road — {nl} lane{'s' if nl > 1 else ''} (car colour = speed)  |  🚦 = Traffic Light", fontsize=8)

        for lane in range(nl):
            y = lane
            ax.axhspan(y - 0.4, y + 0.4, color=LANE_BAND_COLORS[lane % len(LANE_BAND_COLORS)], zorder=0)
            ax.axhline(y, color="#3a3a5a", lw=0.5, ls="--", zorder=1)
            ax.text(L - 0.5, y, f" L{lane+1}", va="center", ha="left", fontsize=6,
                    color=LANE_COLORS[lane % len(LANE_COLORS)], zorder=4)

        self._car_dots = []
        for lane in range(nl):
            sc = ax.scatter([], [], s=55, zorder=3,
                            edgecolors=LANE_COLORS[lane % len(LANE_COLORS)], linewidths=0.4)
            self._car_dots.append(sc)

        # Traffic light vertical lines — one per light
        self._tl_lines = []
        for tl in self.lights:
            color = TL_RED_COLOR if tl.is_red() else TL_GREEN_COLOR
            ln = ax.axvline(tl.position, color=color, lw=2.5, zorder=5, alpha=0.85)
            self._tl_lines.append(ln)

        # Traffic light labels
        self._tl_labels = []
        for tl in self.lights:
            txt = ax.text(tl.position, nl - 0.35, "🔴" if tl.is_red() else "🟢",
                          ha="center", va="top", fontsize=8, zorder=6)
            self._tl_labels.append(txt)

        self._step_text = ax.text(0.99, 0.95, "t = 0", transform=ax.transAxes,
                                  ha="right", va="top", color=TEXT_COLOR, fontsize=8)
        self._flow_text = ax.text(0.01, 0.95, "", transform=ax.transAxes,
                                  ha="left", va="top", color=ACCENT_COLOR, fontsize=8)

    def _init_spacetime_plot(self):
        ax  = self.ax_space
        ax.cla()
        ax.set_facecolor(ROAD_COLOR)
        for sp in ax.spines.values():
            sp.set_color(GRID_COLOR)

        nl  = self.n_lanes
        rpl = self._rows_per_lane

        ax.set_title(f"Space-Time Diagram ({nl} lane{'s' if nl > 1 else ''} stacked)  |  Dashed = Traffic Light", fontsize=8, color=ACCENT_COLOR)
        ax.set_xlabel("Cell", fontsize=7)
        ax.set_ylabel("Time →", fontsize=7)
        ax.xaxis.label.set_color(TEXT_COLOR)
        ax.yaxis.label.set_color(TEXT_COLOR)
        ax.tick_params(colors=TEXT_COLOR, labelsize=6)

        ax.set_yticks([lane * rpl for lane in range(nl)])
        ax.set_yticklabels([f"L{l+1}" for l in range(nl)], color=TEXT_COLOR, fontsize=6)

        self._st_img = ax.imshow(
            self.spacetime, aspect="auto", origin="upper",
            cmap="hot", vmin=0, vmax=1,
            extent=[0, self.road_length, rpl * nl, 0])

        self._st_dividers = []
        for lane in range(1, nl):
            ln = ax.axhline(lane * rpl, color="#4a4a6a", lw=1.2, zorder=5)
            self._st_dividers.append(ln)
            ax.text(self.road_length * 0.98, lane * rpl - 2,
                    f"Lane {lane}", ha="right", va="bottom",
                    color=LANE_COLORS[(lane - 1) % len(LANE_COLORS)], fontsize=6, zorder=6)

        # Vertical dashed lines at light positions in space-time
        self._st_tl_lines = []
        for tl in self.lights:
            ln = ax.axvline(tl.position, color=TL_RED_COLOR if tl.is_red() else TL_GREEN_COLOR,
                            lw=1.2, ls="--", zorder=6, alpha=0.7)
            self._st_tl_lines.append(ln)

    def _init_fund_diagram(self):
        ax      = self.ax_flow
        v_max   = int(self.sl_vmax.val)
        p_brake = self.sl_brake.val
        nl      = self.n_lanes

        dens, flows, _ = compute_fundamental_diagram(
            self.road_length, v_max, p_brake, nl,
            traffic_lights=self.lights)

        ax.cla()
        ax.set_facecolor(ROAD_COLOR)
        ax.plot(dens, flows, color=ACCENT_COLOR, lw=1.5, label=f"{nl} lane{'s' if nl > 1 else ''} + TL")
        ax.set_title("Fundamental Diagram\n(Flow vs Density)", fontsize=8)
        ax.set_xlabel("Density ρ", fontsize=7)
        ax.set_ylabel("Flow Q", fontsize=7)
        ax.grid(True, color=GRID_COLOR, lw=0.4)
        ax.legend(fontsize=6, facecolor=ROAD_COLOR, labelcolor=TEXT_COLOR, framealpha=0.7)

        for sp in ax.spines.values():
            sp.set_color(GRID_COLOR)
        ax.tick_params(colors=TEXT_COLOR, labelsize=6)
        ax.xaxis.label.set_color(TEXT_COLOR)
        ax.yaxis.label.set_color(TEXT_COLOR)
        ax.title.set_color(ACCENT_COLOR)

        self._fund_point, = ax.plot([], [], "o", color="#e94560", ms=7, zorder=5)

    def _init_speed_hist(self):
        ax = self.ax_speed
        ax.cla()
        ax.set_facecolor(ROAD_COLOR)
        ax.set_title("Speed Distribution by Lane", fontsize=8)
        ax.set_xlabel("Speed (cells/step)", fontsize=7)
        ax.set_ylabel("Count", fontsize=7)
        ax.grid(True, color=GRID_COLOR, lw=0.4)
        ax.xaxis.label.set_color(TEXT_COLOR)
        ax.yaxis.label.set_color(TEXT_COLOR)
        ax.title.set_color(ACCENT_COLOR)

    def _init_stats(self):
        ax = self.ax_stats
        ax.cla()
        ax.set_facecolor(ROAD_COLOR)
        ax.set_title("Live Statistics", fontsize=8)
        ax.axis("off")
        ax.title.set_color(ACCENT_COLOR)

        self._stat_texts = {}

        overall_labels = ["Total Cars", "Overall ρ", "Avg Speed", "Flow Q"]
        y_start = 0.96
        ax.text(0.02, y_start, "— Overall —", color=ACCENT_COLOR, fontsize=7,
                transform=ax.transAxes, fontweight="bold")

        for i, lbl in enumerate(overall_labels):
            y = y_start - 0.10 - i * 0.09
            ax.text(0.02, y, f"{lbl}:", color=TEXT_COLOR, fontsize=7, transform=ax.transAxes)
            t = ax.text(0.52, y, "—", color=ACCENT_COLOR, fontsize=7, transform=ax.transAxes, fontweight="bold")
            self._stat_texts[f"overall_{i}"] = t

        y_tl = y_start - 0.10 - len(overall_labels) * 0.09 - 0.03
        ax.text(0.02, y_tl, "— Traffic Lights —", color="#ff9933", fontsize=7,
                transform=ax.transAxes, fontweight="bold")

        self._tl_stat_texts = []
        for i, tl in enumerate(self.lights):
            y = y_tl - 0.10 - i * 0.09
            ax.text(0.02, y, f"TL@{tl.position}:", color="#ff9933", fontsize=7, transform=ax.transAxes)
            t = ax.text(0.52, y, "—", color="#ff9933", fontsize=7, transform=ax.transAxes, fontweight="bold")
            self._tl_stat_texts.append(t)

        y_lane_start = y_tl - 0.10 - len(self.lights) * 0.09 - 0.03
        ax.text(0.02, y_lane_start, "— Per Lane —", color=ACCENT_COLOR, fontsize=7,
                transform=ax.transAxes, fontweight="bold")

        for lane in range(self.n_lanes):
            y = y_lane_start - 0.10 - lane * 0.09
            color = LANE_COLORS[lane % len(LANE_COLORS)]
            ax.text(0.02, y, f"Lane {lane+1}  ρ/v̄/Q:", color=color, fontsize=6.5, transform=ax.transAxes)
            t = ax.text(0.52, y, "—", color=color, fontsize=6.5, transform=ax.transAxes, fontweight="bold")
            self._stat_texts[f"lane_{lane}"] = t

    # ── Event handlers ────────────────────────────────────────────────────────

    def _rebuild_model(self):
        density = self.sl_den.val
        v_max   = int(self.sl_vmax.val)
        p_brake = self.sl_brake.val
        n_cars  = max(self.n_lanes, int(density * self.road_length * self.n_lanes))

        self.model = MultiLaneNaSch(
            self.road_length, n_cars, self.n_lanes, v_max, p_brake,
            traffic_lights=self.lights)
        self._init_spacetime_buffer()
        self._warmup(200)

    def _on_param_change(self, _):
        self._rebuild_model()

    def _on_lane_change(self, _):
        self.n_lanes = int(self.sl_lanes.val)
        self._rebuild_model()
        self._init_road_plot()
        self._init_spacetime_plot()
        self._init_fund_diagram()
        self._init_speed_hist()
        self._init_stats()
        self.fig.canvas.draw_idle()

    def _on_tl_cycle_change(self, _):
        new_cycle = int(self.sl_tlcyc.val)
        for tl in self.lights:
            tl.set_cycle(new_cycle)
        self._rebuild_model()

    def _toggle_pause(self, _):
        self.running = not self.running
        self.btn_pause.label.set_text("▶ Resume" if not self.running else "⏸ Pause")

    def _reset(self, _):
        self.model.reset()
        self._init_spacetime_buffer()
        self._warmup(200)

    def _recompute_fund(self, _):
        self.ax_flow.cla()
        self.ax_flow.set_facecolor(ROAD_COLOR)
        self.ax_flow.set_title("Computing…", color=ACCENT_COLOR, fontsize=8)
        self.fig.canvas.draw_idle()
        self._init_fund_diagram()
        self.fig.canvas.draw_idle()

    # ── Animation update ──────────────────────────────────────────────────────

    def _update(self, frame):
        if not self.running:
            return

        pos_list, vel_list = self.model.step()
        nl    = self.n_lanes
        v_max = self.model.v_max

        # Update car dots
        for lane in range(nl):
            pos = pos_list[lane]
            vel = vel_list[lane]
            if len(pos) > 0:
                colors = [speed_color(v, v_max) for v in vel]
                y_vals = np.full(len(pos), lane)
                self._car_dots[lane].set_offsets(np.c_[pos, y_vals])
                self._car_dots[lane].set_color(colors)
            else:
                self._car_dots[lane].set_offsets(np.empty((0, 2)))

        # Update traffic light visuals
        for i, tl in enumerate(self.lights):
            color = TL_RED_COLOR if tl.is_red() else TL_GREEN_COLOR
            self._tl_lines[i].set_color(color)
            self._tl_labels[i].set_text("🔴" if tl.is_red() else "🟢")
            if i < len(self._st_tl_lines):
                self._st_tl_lines[i].set_color(color)

        self._step_text.set_text(f"t = {self.model.step_count}")
        self._flow_text.set_text(
            f"Q = {self.model.overall_flow():.3f}  |  "
            f"v̄ = {self.model.overall_avg_speed():.2f}  |  "
            f"N = {self.model.total_cars()}")

        self._push_spacetime(pos_list, vel_list)
        self._st_img.set_data(self.spacetime)

        self._fund_point.set_data(
            [self.model.overall_density()], [self.model.overall_flow()])

        # Speed histogram
        ax = self.ax_speed
        ax.cla()
        ax.set_facecolor(ROAD_COLOR)
        speeds = range(v_max + 1)
        bar_w  = 0.8 / max(nl, 1)

        for lane in range(nl):
            vel = vel_list[lane]
            if len(vel) == 0:
                continue
            bins = np.arange(-0.5, v_max + 1.5, 1)
            counts, _ = np.histogram(vel, bins=bins)
            offset = (lane - (nl - 1) / 2) * bar_w
            x_pos  = np.array(list(speeds), dtype=float) + offset
            color  = LANE_COLORS[lane % len(LANE_COLORS)]
            ax.bar(x_pos, counts, width=bar_w * 0.9, color=color, alpha=0.85,
                   edgecolor="#000", lw=0.3, label=f"Lane {lane+1}")

        ax.set_title("Speed Distribution by Lane", fontsize=8)
        ax.set_xlabel("Speed (cells/step)", fontsize=7)
        ax.set_ylabel("Count", fontsize=7)
        ax.set_xticks(list(speeds))
        ax.grid(True, color=GRID_COLOR, lw=0.4, axis="y")
        ax.set_facecolor(ROAD_COLOR)
        for sp in ax.spines.values():
            sp.set_color(GRID_COLOR)
        ax.tick_params(colors=TEXT_COLOR, labelsize=6)
        ax.xaxis.label.set_color(TEXT_COLOR)
        ax.yaxis.label.set_color(TEXT_COLOR)
        ax.title.set_color(ACCENT_COLOR)
        if nl > 1:
            ax.legend(fontsize=6, facecolor=ROAD_COLOR, labelcolor=TEXT_COLOR,
                      framealpha=0.7, loc="upper right")

        # Overall stats
        overall_vals = [
            str(self.model.total_cars()),
            f"{self.model.overall_density():.3f}",
            f"{self.model.overall_avg_speed():.2f}",
            f"{self.model.overall_flow():.3f}",
        ]
        for i, val in enumerate(overall_vals):
            key = f"overall_{i}"
            if key in self._stat_texts:
                self._stat_texts[key].set_text(val)

        # Traffic light stats
        for i, tl in enumerate(self.lights):
            if i < len(self._tl_stat_texts):
                phase = "RED" if tl.is_red() else "GRN"
                steps_left = tl.cycle - (tl._step % tl.cycle)
                self._tl_stat_texts[i].set_text(f"{phase}  ({steps_left}s left)")

        # Per-lane stats
        for lane in range(nl):
            key = f"lane_{lane}"
            if key in self._stat_texts:
                rho = self.model.lane_density(lane)
                spd = self.model.lane_avg_speed(lane)
                flw = self.model.lane_flow(lane)
                self._stat_texts[key].set_text(f"{rho:.2f} / {spd:.2f} / {flw:.3f}")


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("Multi-Lane Traffic Flow Simulation — NaSch Model v4.0 (Traffic Lights)")
    print()
    print("  Step 1: Running Error Analysis figure...")
    print("  (Close that window to launch the interactive simulation.)")
    print()

    run_error_analysis()

    print("  Step 2: Launching interactive simulation with traffic lights...")
    print()
    print("  Traffic lights are placed at cells 25 and 75 (staggered phases).")
    print("  Red/green lines on the road strip show the current state.")
    print("  The TL Cycle slider adjusts the red+green half-period.")
    print()
    print("  Controls:")
    print("  • Density slider    — fraction of cells occupied per lane.")
    print("  • Max Speed slider  — speed ceiling (cells/step).")
    print("  • Brake Prob slider — random-dawdling probability.")
    print("  • Num Lanes slider  — number of parallel lanes (1–4).")
    print("  • TL Cycle slider   — traffic light cycle length (steps).")
    print()
    print("  • ⏸ Pause  — freeze/resume.")
    print("  • ↺ Reset  — randomise positions, keep parameters.")
    print("  • 📊 Recompute — rebuild fundamental diagram.")
    print()

    ui = TrafficSimUI()
